var Serie = /** @class */ (function () {
    function Serie(num, name, channel, seasons, desc, link, img) {
        this.num = num;
        this.name = name;
        this.channel = channel;
        this.seasons = seasons;
        this.desc = desc;
        this.link = link;
        this.img = img;
    }
    return Serie;
}());
export { Serie };